﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio31
{
    public class Negocio
    {
        private static PuestoAtencion Caja;
        private static Queue<Cliente> clientes;
        private static string nombre;

        private Negocio()
        {
            Caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
            clientes = new Queue<Cliente>();
            nombre = "";
        }
        private Negocio(string nombreIng)
        {
            Caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
            clientes = new Queue<Cliente>();
            nombre = nombreIng;
        }

        private Cliente Cliente//setget
        {
            set
            {
                clientes.Enqueue(value);
            }
            get
            {
                return clientes.Dequeue();
            }
        }

        public static bool operator ==(Negocio n, Negocio c)
        {
            bool boolRetorno = false;
            if (n.Cliente == c.Cliente)
            {
                boolRetorno = true;
            }
            return boolRetorno;
        }
        public static bool operator !=(Negocio n, Negocio c)
        {
            bool boolRetorno = false;
            if (n.Cliente == c.Cliente)
            {
                boolRetorno = true;
            }
            return boolRetorno;
        }
        public static bool operator +(Negocio n, Negocio c)
        {
            bool boolRetorno = false;
            if (n.Cliente == c.Cliente)
            {
                n.Cliente = c.Cliente;
            }
            return boolRetorno;
        }
    }
}
