﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ejercicio31
{
    
    public class PuestoAtencion
    {
        public enum Puesto
        {
            Caja1,
            Caja2
        }
        private static int numeroActual;
        private Puesto puesto;

        static PuestoAtencion()//conts
        {
            numeroActual = 0;
        }
        public PuestoAtencion(Puesto puestoIng)//conts
        {
            puesto = puestoIng;
        }
        private int NumeroActual//setget
        {
            get 
            {
                return ++numeroActual;
            }
        }
        public bool Atender(Cliente cli)
        {
            bool boolRetorno = false;
            Thread.Sleep(5000);
            boolRetorno = true;
            return boolRetorno;
        }
    }
}
