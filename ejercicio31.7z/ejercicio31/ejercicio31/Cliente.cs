﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio31
{
    public class Cliente
    {
        private static string nombre;
        private static int numero;
        public Cliente(int numeroIng)
        {
            nombre = "";
            numero = numeroIng;
        }
        public Cliente(int numeroIng, string nombreIng)
        {
            nombre = nombreIng;
            numero = numeroIng;
        }
        public static bool operator ==(Cliente cl1, Cliente cl2)
        {
            bool boolRetorno = false;
            if (cl1.Numero == cl2.Numero)
            {
                boolRetorno = true;
            }
            return boolRetorno;
        }
        public static bool operator !=(Cliente cl1, Cliente cl2)
        {
            bool boolRetorno = false;
            if (cl1.Numero != cl2.Numero)
            {
                boolRetorno = true;
            }
            return boolRetorno;
        }
        private string Nombre//setget
        {
            set
            {
                Cliente.nombre = value;
            }
            get
            {
                return Cliente.nombre;
            }
        }
        private int Numero//setget
        {
            get
            {
                return Cliente.numero;
            }
        }

    }
}
