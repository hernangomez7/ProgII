﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_47
{
    public class Contabilidad<T,U> 
        where T:Documento
        where U:Documento
    {
        private List<T> egreso;
        private List<U> ingreso;
        public Contabilidad()
        {
            egreso = new List<T>();
            ingreso = new List<U>();
        }

        public static Contabilidad<T, U> operator +(Contabilidad<T, U> c, T egreso)
        {
            c.egreso.Add(egreso);
            return c;
        }

        public static Contabilidad<T, U> operator +(Contabilidad<T, U> c, U ingreso)
        {
            c.ingreso.Add(ingreso);
            return c;
        }
    }
}
