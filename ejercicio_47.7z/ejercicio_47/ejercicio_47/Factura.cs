﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_47
{
    public class Factura : Documento
    {
        private int p;

        public Factura(int numero)
        :base(numero)
        { }
    }
}
