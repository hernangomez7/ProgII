﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_47
{
    class Program
    {
        static void Main(string[] args)
        {
            Factura f1 = new Factura(10);
            Recibo r1 = new Recibo(20);
            Contabilidad<Factura, Recibo> Contabilidad1 = new Contabilidad<Factura, Recibo>();

            Contabilidad1 = Contabilidad1 + f1;
            Contabilidad1 = Contabilidad1 + r1;
        }
    }
}
